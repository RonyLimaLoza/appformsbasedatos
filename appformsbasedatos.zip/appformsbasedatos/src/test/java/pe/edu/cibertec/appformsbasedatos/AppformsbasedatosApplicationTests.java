package pe.edu.cibertec.appformsbasedatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppformsbasedatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
