package pe.edu.cibertec.appformsbasedatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppformsbasedatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppformsbasedatosApplication.class, args);
	}

}
